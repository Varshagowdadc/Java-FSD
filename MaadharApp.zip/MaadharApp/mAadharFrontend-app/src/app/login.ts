// map to entity class or json data. 
export class Login {
    constructor(public emailid:string,
        public password:string,
        public typeOfUser:string){}
}